console.log('background script running');
